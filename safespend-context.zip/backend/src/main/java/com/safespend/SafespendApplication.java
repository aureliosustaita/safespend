package com.safespend;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class SafespendApplication {
  public static void main(String[] args){ SpringApplication.run(SafespendApplication.class, args); }
}
